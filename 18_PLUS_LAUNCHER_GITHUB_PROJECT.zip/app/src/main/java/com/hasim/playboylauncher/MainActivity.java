package com.hasim.playboylauncher;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class MainActivity extends Activity {
    private WebView webView;
    private SharedPreferences prefs;
    private final String[] keys = {"app_x", "app_o", "app_globe"};
    private final String[] slotNames = {"X (ikon kiri)", "O (ikon tengah)", "Globe (ikon kanan)"};

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("launcher_settings", MODE_PRIVATE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().setNavigationBarColor(0xFF080008);
        getWindow().setStatusBarColor(0xFF080008);

        webView = new WebView(this);
        webView.setBackgroundColor(0xFF080008);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new LauncherBridge(), "AndroidLauncher");
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    private class LauncherBridge {
        @JavascriptInterface public void showSettings() {
            runOnUiThread(() -> showSlotChooser());
        }
        @JavascriptInterface public void launch(int slot) {
            runOnUiThread(() -> launchSavedApp(slot));
        }
    }

    private void showSlotChooser() {
        String[] choices = new String[3];
        for (int i=0;i<3;i++) {
            String pkg = prefs.getString(keys[i], "");
            String app = getAppLabel(pkg);
            choices[i] = slotNames[i] + (app.isEmpty() ? " — belum dipilih" : " — " + app);
        }
        new AlertDialog.Builder(this)
                .setTitle("PENGATURAN TOMBOL")
                .setItems(choices, (d, which) -> showInstalledApps(which))
                .setNegativeButton("Tutup", null)
                .show();
    }

    private void showInstalledApps(int slot) {
        Intent intent = new Intent(Intent.ACTION_MAIN, null);
        intent.addCategory(Intent.CATEGORY_LAUNCHER);
        PackageManager pm = getPackageManager();
        List<ResolveInfo> apps = pm.queryIntentActivities(intent, 0);
        Collections.sort(apps, (a,b) -> {
            String x = a.loadLabel(pm).toString();
            String y = b.loadLabel(pm).toString();
            return x.compareToIgnoreCase(y);
        });

        ArrayList<String> labels = new ArrayList<>();
        ArrayList<String> packages = new ArrayList<>();
        for (ResolveInfo info : apps) {
            String pkg = info.activityInfo.packageName;
            if (pkg.equals(getPackageName())) continue;
            labels.add(info.loadLabel(pm).toString());
            packages.add(pkg);
        }
        if (labels.isEmpty()) {
            Toast.makeText(this, "Tidak ada aplikasi yang ditemukan.", Toast.LENGTH_SHORT).show();
            return;
        }
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                android.R.layout.select_dialog_item, labels);
        new AlertDialog.Builder(this)
                .setTitle("PILIH APLIKASI — " + slotNames[slot])
                .setAdapter(adapter, (dialog, which) -> {
                    prefs.edit().putString(keys[slot], packages.get(which)).apply();
                    Toast.makeText(this, labels.get(which) + " disimpan.", Toast.LENGTH_SHORT).show();
                })
                .setNeutralButton("Hapus pilihan", (dialog, which) -> {
                    prefs.edit().remove(keys[slot]).apply();
                    Toast.makeText(this, "Pilihan dihapus.", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("Batal", null)
                .show();
    }

    private String getAppLabel(String pkg) {
        if (pkg == null || pkg.isEmpty()) return "";
        try { return getPackageManager().getApplicationLabel(
                getPackageManager().getApplicationInfo(pkg, 0)).toString(); }
        catch (Exception e) { return ""; }
    }

    private void launchSavedApp(int slot) {
        if (slot < 0 || slot > 2) return;
        String pkg = prefs.getString(keys[slot], "");
        if (pkg.isEmpty()) {
            Toast.makeText(this, "Pilih aplikasi lewat ikon pengaturan dahulu.", Toast.LENGTH_SHORT).show();
            return;
        }
        Intent launch = getPackageManager().getLaunchIntentForPackage(pkg);
        if (launch != null) {
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(launch);
        } else {
            Toast.makeText(this, "Aplikasi tidak ditemukan. Pilih ulang di pengaturan.", Toast.LENGTH_SHORT).show();
        }
    }

    @Override public void onBackPressed() {
        // Launcher stays on its home screen; Android Home button remains available.
        Toast.makeText(this, "Tekan tombol Home untuk keluar ke launcher lain.", Toast.LENGTH_SHORT).show();
    }
}
