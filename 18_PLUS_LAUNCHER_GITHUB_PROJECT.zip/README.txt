18+ — ANDROID PROJECT

FITUR
- Wallpaper portrait dari gambar yang kamu kirim.
- Hanya tiga area tombol transparan di atas ikon X, O, dan Globe.
- Pengaturan kecil di pojok kanan atas.
- Pengaturan membuka daftar aplikasi yang benar-benar terpasang di Android.
- Pilihan aplikasi tersimpan setelah aplikasi ditutup/restart.
- Bisa didaftarkan sebagai launcher Home Android.

ICON
- Ikon aplikasi menggunakan PNG yang kamu kirim.
- Area hitam yang menyentuh tepi gambar dihapus menjadi transparan.
- Tidak ditambahkan bidang hitam di luar artwork.

BUILD VIA GITHUB
CARA KHUSUS JIKA HANYA BISA UPLOAD SATU ZIP DARI HP
1. Buat repository GitHub baru.
2. Buat file workflow sekali saja di GitHub: .github/workflows/build.yml
3. Salin isi file PLAYBOY_LAUNCHER_build.yml yang saya berikan ke file workflow tersebut, lalu Commit.
4. Upload file PLAYBOY_LAUNCHER_GITHUB_PROJECT.zip ke root repository sebagai satu file.
5. Setelah upload, buka tab Actions. Workflow akan otomatis mengekstrak ZIP dan membangun APK.
6. Buka hasil run dan download artifact PLAYBOY-LAUNCHER-APK.
7. Ekstrak artifact ZIP untuk mendapatkan app-debug.apk.

CATATAN
- Build ini adalah APK debug untuk tes, belum APK release bertanda tangan.
- Setelah instalasi, Android dapat menanyakan launcher Home default. Pilih 18+ jika ingin menjadikannya layar Home.
- Pada beberapa Android 11+ vendor, daftar aplikasi dapat dibatasi kebijakan sistem; manifest sudah menyertakan query launcher.
